from IoP import app
app.run(debug=True)
